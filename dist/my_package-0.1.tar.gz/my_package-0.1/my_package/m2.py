# mypackage/module2.py

def function2():
    return "Hello from module2"

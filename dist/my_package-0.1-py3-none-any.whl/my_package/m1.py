# mypackage/module1.py

def function1():
    return "Hello from module1"
